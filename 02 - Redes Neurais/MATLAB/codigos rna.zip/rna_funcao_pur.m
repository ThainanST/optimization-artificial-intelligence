% Exemplo de aplica��o de Redes Neurais Artificiais

clear all
clc

% Conjunto de treinamento (tr)
E1 = [ 0 1 2 3 4 5 6 7 8 9 ];

S1 = [0 1 1.4142 1.7321 2 2.2361 2.4495 2.6458 2.8284 3];

ft='trainrp';

nnco = 3; % N�mero de neur�nios da camada oculta
nncs = 1; % N�mero de neur�nios da camada de sa�da

% fs  = 'tansig';
% fco = 'tansig';
fs  = 'purelin';
fco = 'purelin';

net = newff(minmax(E1),[nnco,nncs],{fco,fs},ft); % 1 camada oculta !

net.layers{1}
net.IW{1}
net.LW{2}
net.b{1}
net.b{2}

E2 = 2
S2 = sim(net,E2)
S2 = round(S2)
    
net.trainParam.epochs = 1000;
net.trainParam.goal   = 0.01;
net.trainParam.min_grad = 1e-5;

net = init(net);

[net,tr]=train(net,E1,S1,[],[]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot(tr.epoch, tr.perf);
ylabel('erro quadratico'); xlabel('Epoca');


E2 = 4
S2 = sim(net,E2)
    
% Exemplo de aplica��o de Redes Neurais Artificiais

clear all
clc

% Conjunto de treinamento (tr)
E1 = [ 0 0 ; 0 1; 1 0; 1 1 ];

S1 = [0 1 1 1];

E1 = E1';


ft='trainrp';

nnco = 1; % N�mero de neur�nios da camada oculta
nncs = 1; % N�mero de neur�nios da camada de sa�da

% fs  = 'tansig';
% fco = 'tansig';
fs  = 'purelin';
fco = 'purelin';

% net = newff(minmax(E1),[nnco,nncs],{fco,fs},ft); % 1 camada oculta !
load net

net.layers{1}
net.IW{1}
net.LW{2}
net.b{1}
net.b{2}

E2 = [0 0]'
S2 = sim(net,E2)
S2 = round(S2)
    
E2 = [0 1]'
S2 = sim(net,E2)
S2 = round(S2)

E2 = [1 0]'
S2 = sim(net,E2)
S2 = round(S2)

E2 = [1 1]'
S2 = sim(net,E2)
S2 = round(S2)

net.trainParam.epochs = 1000;
net.trainParam.goal   = 0.01;
net.trainParam.min_grad = 1e-5;

net = init(net);

[net,tr]=train(net,E1,S1,[],[]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot(tr.epoch, tr.perf, tr.epoch, tr.vperf);
% plot(tr.epoch, tr.vperf);
plot(tr.epoch, tr.perf);
% hold on
% plot(tr.epoch, tr.vperf);
ylabel('erro quadratico'); xlabel('Epoca');




E2 = [0 0]'
S2 = sim(net,E2)
S2 = round(S2)
    
E2 = [0 1]'
S2 = sim(net,E2)
S2 = round(S2)

E2 = [1 0]'
S2 = sim(net,E2)
S2 = round(S2)

E2 = [1 1]'
S2 = sim(net,E2)
S2 = round(S2)

